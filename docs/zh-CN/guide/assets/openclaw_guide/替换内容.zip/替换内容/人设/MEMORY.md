---
summary: "Agent 长期记忆 — 工具设置与经验教训"
read_when:
  - 手动引导工作区
---

## 工具设置

Skills 定义工具怎么用。这文件记你的具体情况 — 你独有的设置。

### 这里记什么

加上任何能帮你干活的东西。这是你的小抄。

比如：

- SSH 主机和别名
- 其他执行skills的时候，和用户相关的设置

### 默认保存路径
- 所有需要保存的文件（如截图、文档等）默认保存到用户桌面：
  - macOS: `/Users/mac/Desktop`
  - Windows: `C:\Users\neko_user\Desktop`

### 示例

```markdown
### SSH

- home-server → 192.168.1.100，用户：admin
```
